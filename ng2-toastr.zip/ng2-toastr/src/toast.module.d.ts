import { ModuleWithProviders } from '@angular/core';
export declare class ToastModule {
    static forRoot(): ModuleWithProviders;
}
