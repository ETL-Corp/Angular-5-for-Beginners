import { InMemoryDbService } from 'angular-in-memory-web-api';

  export class ServerdataService  implements InMemoryDbService {
    createDb() {
      const servers = [
        { application: 'OM', server: 'r00005n0z', region: 'PROD', servertype: 'APP'},
        { application: 'Workflow', server: 'r00005n0z', region: 'QA', servertype: 'WEB'},
        { application: 'PQRS', server: 'r00005n0z', region: 'XAT', servertype: 'APP'},
        { application: 'COB', server: 'r00005n0z', region: 'DEMO', servertype: 'WEB'},
        { application: 'RCD', server: 'r00005n0z', region: 'UAT', servertype: 'APP'},
        { application: 'AMPS', server: 'r00005n0z', region: 'PROD', servertype: 'WEB'}      ];
      return {servers};
    }
  }