import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';

import { Server,Hero } from './hero';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ServerService {

  private heroesUrl = 'api/servers';  // URL to web api

  constructor(
    private http: HttpClient) { }

  /** GET heroes from the server */
  getHeroes (): Observable<Server[]> {
    return this.http.get<Server[]>(this.heroesUrl)
      .pipe(
      );
  }

  /** GET hero by id. Return `undefined` when id not found */
  getHeroNo404<Data>(Server: number): Observable<Hero> {
    const url = `${this.heroesUrl}/?server=${Server}`;
    return this.http.get<Hero[]>(url)
      .pipe(
        map(servers => servers[0]), // returns a {0|1} element array
      );
  }

  /** GET hero by id. Will 404 if id not found 
  getHero(id: number): Observable<Hero> {
    const url = `${this.heroesUrl}/${id}`;
    return this.http.get<Hero>(url).pipe(
      //tap(_ => this.log(`fetched hero id=${id}`)),
      catchError(this.handleError<Hero>(`getHero id=${id}`))
    );
  }*/

  /* GET heroes whose name contains search term */
  searchHeroes(term: string): Observable<Server[]> {
    if (!term.trim()) {
      // if not search term, return empty hero array.
      return of([]);
    }
    return this.http.get<Server[]>(`api/servers/?name=${term}`).pipe(
    );
  }
}
