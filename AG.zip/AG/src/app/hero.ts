export class Hero {
  id: number;
  name: string;
}


export class Server {
 application: string;
 server: string;
 region: string;
 servertype: string;
}