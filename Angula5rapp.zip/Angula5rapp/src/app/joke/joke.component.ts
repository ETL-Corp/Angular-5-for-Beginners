import { Input,Component, OnInit } from '@angular/core';
import { Joke } from '../Joke';

@Component({
  selector: 'app-joke',
  templateUrl: './joke.component.html',
  styleUrls: ['./joke.component.css']
})
export class JokeComponent implements OnInit {
  @Input() joke : Joke;
/*  msg : String;
  setup: string;
  punchline: string;
  constructor() {
  this.setup = "What did the cheese say when it looked in the mirror?";
  this.punchline = "Halloumi (Hello Me)";
  this.msg="Tested case 1 : Property initialized";
  }*/

  ngOnInit() {
  }

}
